const chalk = require("chalk")
const fs = require("fs")

global.ownerNumber = ["243997997705@s.whatsapp.net"]
global.nomerOwner = "243997997705"
global.nomorOwner = ['243997997705']
global.namaDeveloper = "▒▓█ᴷⁱⁿᴳ➷𝐊𝐀𝐘𝐀᭄ₛₛₖ█▓▒" //jangn diubh bng
global.namaOwner = "▒▓█ᴷⁱⁿᴳ➷𝐊𝐀𝐘𝐀᭄ₛₛₖ█▓▒"
global.namaBot = "💀𝐊𝐀𝐘𝐀▞▚𝐁𝐔𝐆 1💀"
global.versionBot = "𝟏𝟓.𝟎.𝟐"
global.packname = "▒▓█ᴷⁱⁿᴳ➷𝐊𝐀𝐘𝐀᭄ₛₛₖ█▓▒"
global.author = "▒▓█ᴷⁱⁿᴳ➷𝐊𝐀𝐘𝐀᭄ₛₛₖ█▓▒"
global.thumb = fs.readFileSync("./Andrazyy Forger.jpg")
global.ThM = 'https://files.catbox.moe/8blo3x.jpeg'

let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})